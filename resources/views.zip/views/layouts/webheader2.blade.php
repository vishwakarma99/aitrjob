<!DOCTYPE html>

<html lang="en">

<head>

	<meta charset="utf-8">

	<meta http-equiv="X-UA-Compatible" content="IE=edge">

	<meta name="keywords" content="" />

	<meta name="author" content="" />

	<meta name="robots" content="" />

	<meta name="description" content="Aitrjobs" />

	<meta property="og:title" content="Aitrjobs" />

	<meta property="og:description" content="Aitrjobs" />

	<meta property="og:image" content="Aitrjobs" />

	<meta name="format-detection" content="telephone=no">

	<meta name="csrf-token" content="{{ csrf_token() }}" />	

	<!-- FAVICONS ICON -->

	<link rel="icon" href="{{ asset('/web-assets/images/favicon.ico')}}" type="image/x-icon" />

	<link rel="shortcut icon" type="image/x-icon" href="{{ asset('/web-assets/images/favicon.png')}}" />

	<!-- PAGE TITLE HERE -->

	<title>Aitrjobs</title>



	<!-- MOBILE SPECIFIC -->

	<meta name="viewport" content="width=device-width, initial-scale=1">



	<!--[if lt IE 9]>

	<script src="js/html5shiv.min.js"></script>

	<script src="js/respond.min.js"></script>

	<![endif]-->



	<!-- STYLESHEETS -->
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons+Outlined">
	<link rel="stylesheet" type="text/css" href="{{ asset('/web-assets/css/plugins.css')}}">

	<link rel="stylesheet" type="text/css" href="{{ asset('/web-assets/css/style.css')}}">

	<link rel="stylesheet" type="text/css" href="{{ asset('/web-assets/css/templete.css')}}">
	<link rel="stylesheet" type="text/css" href="{{ asset('/web-assets/css/simplePagination.css')}}">

	<link class="skin" rel="stylesheet" type="text/css" href="{{ asset('/web-assets/css/skin/skin-1.css')}}">

	<link type="text/css" rel="stylesheet" href="{{ asset('/web-assets/css/firebase-ui-auth.css')}}" />
	
	

</head>

<body id="bg">

	<!-- <div id="loading-area"></div> -->

	<div class="page-wraper">

		<!-- header -->

		<header class="site-header mo-left header fullwidth">

			<!-- main header -->

			<div class="sticky-header main-bar-wraper navbar-expand-lg">

				<div class="main-bar clearfix">

					<div class="container clearfix">

						<!-- website logo -->

						<div class="logo-header mostion">

							<a href="{{ URL::to('/') }}"><img src="{{ asset('web-assets/images/logo.png') }}" class="logo" alt=""></a>

						</div>

						<!-- nav toggle button -->

						<!-- nav toggle button -->

						<button class="navbar-toggler collapsed navicon justify-content-end" type="button"
							data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown"
							aria-expanded="false" aria-label="Toggle navigation">

							<span></span>

							<span></span>

							<span></span>

						</button>
						<input type="hidden" name="auth" id="auth" value="{{ Session::get('Auth_Uid_AirtrJobs') }}">
						<!-- extra nav -->

						<div class="extra-nav">

							<div class="extra-cell">

								@if(session()->get('Auth_Role_AirtrJobs') == 1)
                                    <a href="{{ URL::to('signup') }}" class="site-button"> Employer</a>
								@elseif (session()->get('Auth_Role_AirtrJobs') == 2)
									<a href="{{ URL::to('signup') }}" class="site-button"> job seeker</a>
								@else
									<a href="{{ URL::to('signup') }}" class="site-button"> job seeker</a>
									
								@endif
								

								<a href="#"> <i class="fa fa-bell" aria-hidden="true" style="font-size: 30px;
									margin: 0px 10px 0px 18px;"></i> </a>
								<a href="#"> <i class="fa fa-envelope" aria-hidden="true"
										style="font-size: 30px;margin: 0px 10px 0px 18px;"></i> </a>
							</div>

						</div>

						<!-- main nav -->

						<div class="header-nav navbar-collapse collapse justify-content-start" id="navbarNavDropdown">

							<ul class="nav navbar-nav">
								<li class="active">
									<a href="{{ URL::to('/') }}">Home <i class="fa fa-chevron"></i></a>
								</li>
								<li>
									<a href="{{ URL::to('posted-jobs') }}">Jobs </a>
								</li>
								<li>
									<a href="{{ URL::to('companies') }}">Companies <i class="fa fa-chevron"></i></a>
								</li>
								<li>

								@if(session()->get('Auth_Role_AirtrJobs') == 1)
                                    <a href="#">Dashboard <i class="fa fa-chevron-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="{{ URL::to('myProfile') }}" class="dez-page">Profile</a></li>
                                        <li><a href="{{ URL::to('myprofile.html') }}" class="dez-page">Profile Detail
                                            </a></li>
                                    </ul>
								@elseif (session()->get('Auth_Role_AirtrJobs') == 2)
									<a href="#">Dashboard <i class="fa fa-chevron-down"></i></a>
                                    <ul class="sub-menu">
                                        <li><a href="{{ URL::to('myProfile') }}" class="dez-page">Profile</a></li>
                                        <li><a href="{{ URL::to('myprofile.html') }}" class="dez-page">Profile Detail
                                            </a></li>
                                        <li><a href="{{ URL::to('post-new-job') }}" class="dez-page"> Post New Job</a></li>
                                        <li><a href="{{ URL::to('manage-jobs') }}" class="dez-page">Manage Jobs</a></li>
                                        <li><a href="{{ URL::to('hired-profiles') }}" class="dez-page">Hired Profile</a></li>
                                        <li><a href="{{ URL::to('pending-profiles') }}" class="dez-page">Pending Profile</a></li>
                                            
                                        <li><a href="employer_change_password.html" class="dez-page">Change Password</a>
                                        </li>
                                    </ul>
								@else
									<a href="{{ URL::to('signup') }}">Employer </a>
								@endif
                            	</li>
								
								<li>
									<a href="{{ URL::to('blogs') }}">Blog <i class="fa fa-chevron"></i></a>
								</li>
								<li>
									<a href="#">Subjects <i class="fa fa-chevron-down"></i></a>
									<ul class="sub-menu">
										<li><a href="Acadamic_Faculty.html" class="dez-page">
												Acadamic Faculty<span class="new-page">New</span></a></li>

										<li><a href="NTSE-Olympiard.html" class="dez-page">
												NTSE-Olympiard
												<span class="new-page">New</span></a></li>
									</ul>
								</li>
							</ul>

						</div>

					</div>

				</div>

			</div>

			<!-- main header END -->

		</header>

		<!-- header END -->